package com.packt.microservices.calculator2;

public class FetchConstantService {

	/***
	 * Sample method to get a constant value
	 * @return
	 */
	public float getConstantValue() {
		// TODO this is an example method. We might fetch this constant from a third party service.
		return 5;
		
	}

}
