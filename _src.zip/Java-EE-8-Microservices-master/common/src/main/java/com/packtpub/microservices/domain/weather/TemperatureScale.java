package com.packtpub.microservices.domain.weather;

public enum TemperatureScale {
    CELSIUS, FAHRENHEIT
}
