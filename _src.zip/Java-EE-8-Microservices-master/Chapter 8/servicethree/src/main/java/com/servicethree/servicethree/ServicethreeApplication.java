package com.servicethree.servicethree;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicethreeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicethreeApplication.class, args);
	}
}
